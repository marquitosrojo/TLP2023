#Ejercicio 10. 11 de abril. Hacer un programa que pida dos valores que son las coordenadas (x,y) y mostrar los datos indicando el "punto es x,y".
# Pedir las coordenadas x e y al usuario
x = float(input("Ingrese la coordenada x: "))
y = float(input("Ingrese la coordenada y: "))

# Mostrar los datos del punto
print("El punto es ({}, {})".format(x, y))
